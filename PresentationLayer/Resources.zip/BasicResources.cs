﻿namespace Resources
{
	public class BasicResources
	{

	}
}
