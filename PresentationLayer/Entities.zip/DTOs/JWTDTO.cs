﻿namespace Entities.DTOs
{
    public class JWTDTO
    {
        public string? Email { get; set; }
        public string? Name { get; set; }
    }
}
