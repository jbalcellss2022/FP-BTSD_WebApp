﻿namespace Resources
{
	internal class APIResources
	{
	}
}
